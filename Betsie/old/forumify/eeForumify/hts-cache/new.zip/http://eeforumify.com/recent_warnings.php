<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="ROBOTS" content="NOINDEX, FOLLOW"/>
<title>Warning system / Everybody Edits Forums</title>
<link rel="shortcut icon" href="//favicon.ico"/>
<link rel="stylesheet" type="text/css" href="style/Novin1.css?v=2"/>
<!--[if lte IE 6]><script type="text/javascript" src="style/imports/minmax.js"></script><![endif]-->
<style type="text/css">.gid1{color:#00FF00;font-weight:bold}.gid2{color:#97FFFF;font-weight:bold}.gid10{color:#E43AFF;font-weight:bold}.gid11{color:#660099;font-weight:bold}.gid12{color:#00FFCC;font-weight:bold}.gid13{font-weight:bold}.gid14{color:#34DDDD;font-weight:bold}.gid15{color:#ff0000;font-weight:bold}.gid16{font-weight:bold}.gid17{color:#FFCC00;font-weight:bold}</style>
 
<link rel="stylesheet" media="screen" href="style/Novin1/archnavbar.css?v=14"/>
<link rel="shortcut icon" href="glasses.ico"/>
</head>
<body>
<div id="archnavbarlogo">
<img src="style/Novin1/forumheader.png" usemap="#clickable" border="none">
<map name="clickable">
<area shape="rect" coords="185, 93, 523, 17" href="index.php">
</map>
</div>
<div id="archnavbar" class="anb-forum">
<div id="archnavbarmenu">
<ul id="archnavbarlist">
<div id="archnavbaritems">
<li id="navindex" class="isactive"><a href="index.php">Index</a></li>
<li id="navregister"><a href="register.php">Register</a></li>
<li id="navlogin"><a href="login.php">Login</a></li>
<li id="navextra1"><a href="misc.php?action=rules">Rules</a></li>
<li id="navextra2"><a href="recent_warnings.php">Warnings</a></li>
</div>
</ul>
</div>
</div>
<div id="punrecent_warnings" class="pun">
<div class="top-box"><div> </div>
</div>
<div class="punwrap">
<div id="brdwelcome" class="inbox">
<p class="conl">You are not logged in.</p>
<div class="clearer"></div>
</div>
</div>
<div id="announce" class="block">
<div class="hd"><h2><span>Announcement</span></h2></div>
<div class="box">
<div id="announce-block" class="inbox">
<div class="usercontent"><center><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="GW2SLCWAWZFEY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
</center></div>
</div>
</div>
</div>
<br/><br/>
<div id="brdmain">
<div class="linkst">
<div class="inbox crumbsplus">
<div class="pagepost">
<p class="pagelink conl"><span class="pages-label">Pages: </span><strong class="item1">1</strong> <a href="recent_warnings.php?v=1&amp;p=2">2</a> <a href="recent_warnings.php?v=1&amp;p=3">3</a> <a href="recent_warnings.php?v=1&amp;p=4">4</a> <a href="recent_warnings.php?v=1&amp;p=5">5</a> <a rel="next" href="recent_warnings.php?v=1&amp;p=2">Next</a></p>
</div>
<div class="clearer"></div>
</div>
</div>
<div id="recent_warnings" class="blocktable">
<h2><span>Recent warnings</span></h2>
<div class="box">
<div class="inbox">
<table cellspacing="0">
<thead>
<tr>
<th style="width: 25%" align="left" scope="col">Warning</th>
<th style="width: 15%" align="left" scope="col">Date issued</th>
<th class="tc3" style="width: 5%" scope="col">Points</th>
<th class="tcr" style="width: 14%" scope="col">Warned user</th>
<th class="tcr" style="width: 10%" scope="col">Issued by</th>
<th class="tc3" style="width: 4%" scope="col">Details</th>
<th class="tc3" style="width: 60%" scope="col">Message</th>
</tr>
</thead>
<tbody>
<tr>
<td style="width: 25%" align="center">Custom warning: Assisting with ban evasion.</td>
<td style="width: 15%" align="center">2015-02-04 19:28:52</td>
<td class="tc3" style="width: 5%">4</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=5616">skullz16</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=519276#p519276">Post</a></p> </td>
<td class="tc3" style="width: 100%"> Assisting with ban evasion. </td>
</tr>
<tr>
<td style="width: 25%" align="center">1 word post ( 1 more word of extra content )</td>
<td style="width: 15%" align="center">2015-01-22 17:43:07</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=41790">Vitalijus</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=518362#p518362">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">A user has swore directly at someone else.</td>
<td style="width: 15%" align="center">2015-01-18 00:42:42</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=518014#p518014">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">Custom warning: Watch the swearing.</td>
<td style="width: 15%" align="center">2015-01-18 00:41:26</td>
<td class="tc3" style="width: 5%">0</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=518029#p518029">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">1 word post ( 1 more word of extra content )</td>
<td style="width: 15%" align="center">2015-01-14 21:06:24</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=11711">anch159</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=517306#p517306">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">Custom warning: Seriously what is wrong with you</td>
<td style="width: 15%" align="center">2015-01-11 02:44:45</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=517520#p517520">Post</a></p> </td>
<td class="tc3" style="width: 100%"> What are you doing </td>
</tr>
<tr>
<td style="width: 25%" align="center">Custom warning: Gravedig</td>
<td style="width: 15%" align="center">2015-01-10 22:31:08</td>
<td class="tc3" style="width: 5%">0</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=28728">drstereos</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=517465#p517465">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">User has spammed</td>
<td style="width: 15%" align="center">2015-01-10 18:14:15</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=14614">Wizard2002</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=517445#p517445">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">User has spammed</td>
<td style="width: 15%" align="center">2015-01-08 23:57:11</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=41790">Vitalijus</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=4601"><span class="gid2">lrussell</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=517304#p517304">Post</a></p> </td>
<td class="tc3" style="width: 100%"> Grave-dug a year old thread with irrelevant information. </td>
</tr>
<tr>
<td style="width: 25%" align="center">1 word post ( 1 more word of extra content )</td>
<td style="width: 15%" align="center">2015-01-05 09:49:52</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=10333">strider</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=516981#p516981">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">Custom warning: Blatant racism</td>
<td style="width: 15%" align="center">2015-01-04 00:29:35</td>
<td class="tc3" style="width: 5%">2</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=2033">Muftwin</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=516803#p516803">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">A user has swore directly at someone else.</td>
<td style="width: 15%" align="center">2015-01-04 00:27:49</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=516741#p516741">Post</a></p> </td>
<td class="tc3" style="width: 100%"> </td>
</tr>
<tr>
<td style="width: 25%" align="center">User has spammed</td>
<td style="width: 15%" align="center">2015-01-02 03:57:31</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=516543#p516543">Post</a></p> </td>
<td class="tc3" style="width: 100%"> stay on topic and play nice with the other kiddies </td>
</tr>
<tr>
<td style="width: 25%" align="center">User has spammed</td>
<td style="width: 15%" align="center">2015-01-01 13:41:46</td>
<td class="tc3" style="width: 5%">1</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
<td class="tcr" style="width: 4%">
<p><a href="viewtopic.php?pid=516481#p516481">Post</a></p> </td>
<td class="tc3" style="width: 100%"> Spamming with lots of blank new lines. </td>
</tr>
<tr>
<td style="width: 25%" align="center">Direct Perma ban</td>
<td style="width: 15%" align="center">2014-12-30 12:30:10</td>
<td class="tc3" style="width: 5%">12</td>
<td class="tcr" style="width: 15%"><a href="profile.php?id=42809">BrandonS</a></td>
<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
<td class="tcr" style="width: 4%">
<p><a href="#">None</a></p> </td>
<td class="tc3" style="width: 100%"> Bye bye Jawapa. Come back again to seal your fate.
<3 ~atilla </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: DP</td>
					<td style="width: 15%" align="center">2014-12-25 13:04:16</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42996">FAITHPOY0206</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=515833#p515833">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-12-23 12:06:24</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42491">AntonioS300</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=515401#p515401">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: 0PW - Don't gravedig</td>
					<td style="width: 15%" align="center">2014-12-22 07:04:11</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=43011">alin20137</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=515472#p515472">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Flaming</td>
					<td style="width: 15%" align="center">2014-12-22 01:52:55</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=515428#p515428">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Bimps no you can't say that. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: DP</td>
					<td style="width: 15%" align="center">2014-12-18 03:31:35</td>
					<td class="tc3" style="width: 5%">2</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=1923">benedanika</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=514824#p514824">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">1 word post ( 1 more word of extra content )</td>
					<td style="width: 15%" align="center">2014-12-12 01:34:12</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=513921#p513921">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Jawapa</td>
					<td style="width: 15%" align="center">2014-12-09 15:09:34</td>
					<td class="tc3" style="width: 5%">50</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=43007">Arie2002CSB</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="#">None</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: pls2 grow up</td>
					<td style="width: 15%" align="center">2014-12-06 04:21:32</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=31069">Pingohits</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=513282#p513282">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> pls2be growing the up. I know this is a forum for a game that's played by 8 year olds, but that doesn't mean we have to act like 8 year olds. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-11-29 20:41:02</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42999">bosoca</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=512682#p512682">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Please keep your posts on-topic. If you have something to say to a specific user, a PM would be the best way to contact them. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Direct Perma ban</td>
					<td style="width: 15%" align="center">2014-11-22 00:16:34</td>
					<td class="tc3" style="width: 5%">12</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42989">PieFlavoredPie</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="#">None</a></p>					</td>
					<td class="tc3" style="width: 100%"> Ban evasion. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: #Jawapa</td>
					<td style="width: 15%" align="center">2014-11-21 14:46:39</td>
					<td class="tc3" style="width: 5%">15</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42985">ThisIsTheEnd</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="#">None</a></p>					</td>
					<td class="tc3" style="width: 100%"> HAHA </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">A user has swore directly at someone else.</td>
					<td style="width: 15%" align="center">2014-11-15 19:35:58</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=16868">Mr. Force</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=511524#p511524">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> You're taking it just a little too far, dude. It's just a game. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Flaming and direct profanity</td>
					<td style="width: 15%" align="center">2014-11-15 14:11:43</td>
					<td class="tc3" style="width: 5%">2</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=2359">theditor</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=511572#p511572">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Abuse of the report system</td>
					<td style="width: 15%" align="center">2014-11-14 15:48:25</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42491">AntonioS300</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="#">None</a></p>					</td>
					<td class="tc3" style="width: 100%"> Do not report a post or user that does not break the rules. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Abuse of any system e.g. reports, reputation</td>
					<td style="width: 15%" align="center">2014-11-12 21:42:19</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=4491">ZeldaXD</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=511334#p511334">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Do not circumvent the language filters. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Offensive language / Evading the censors</td>
					<td style="width: 15%" align="center">2014-11-12 18:26:59</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=4491">ZeldaXD</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=511326#p511326">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Personal Information</td>
					<td style="width: 15%" align="center">2014-11-12 02:01:51</td>
					<td class="tc3" style="width: 5%">2</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=40643">Creature</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=4601"><span class="gid2">lrussell</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="#">None</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-11-07 18:37:53</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=870">treejoe4</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=510800#p510800">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Raid threat</td>
					<td style="width: 15%" align="center">2014-11-07 00:02:36</td>
					<td class="tc3" style="width: 5%">10</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=4489">Fdoou</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=510756#p510756">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Threatening to post child pornography. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Name-calling</td>
					<td style="width: 15%" align="center">2014-11-06 19:45:22</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=4491">ZeldaXD</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=510733#p510733">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Indirect insults. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-11-05 03:54:37</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=4489">Fdoou</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=510629#p510629">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Spam</td>
					<td style="width: 15%" align="center">2014-11-04 18:05:21</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=496">Pyromaniac</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=510602#p510602">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Watch the death threats, some users felt concerned about it</td>
					<td style="width: 15%" align="center">2014-11-01 16:06:17</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=510023#p510023">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-10-31 03:46:20</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=6389">some man</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=509937#p509937">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Stay on topic</td>
					<td style="width: 15%" align="center">2014-10-31 02:41:11</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=509981#p509981">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Irrelevant post. [0-PW] </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-10-30 19:32:49</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=40643">Creature</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=509939#p509939">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has offensive avatar / signature</td>
					<td style="width: 15%" align="center">2014-10-29 21:06:23</td>
					<td class="tc3" style="width: 5%">2</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=2315">Onjit</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=509670#p509670">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Please endeavor to contribute</td>
					<td style="width: 15%" align="center">2014-10-25 13:12:08</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=4489">Fdoou</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=509300#p509300">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Gravedigging</td>
					<td style="width: 15%" align="center">2014-10-20 17:02:38</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=3545">Awesomenessgood</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=1365"><b style="color: #00A0ff">XxAtillaxX</b></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=508889#p508889">Post</a></p>					</td>
					<td class="tc3" style="width: 100%"> Posted in a topic from 2010 where it is no longer relevant and has no possibility for useful, relevant content. </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: necrodig</td>
					<td style="width: 15%" align="center">2014-10-14 17:50:15</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=6158">N1KF</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=508136#p508136">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Flaming</td>
					<td style="width: 15%" align="center">2014-10-08 19:47:35</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=2359">theditor</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=507635#p507635">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">1 word post ( 1 more word of extra content )</td>
					<td style="width: 15%" align="center">2014-10-07 18:27:55</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=1779">Bimps</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=507551#p507551">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">Custom warning: Racism / inappropriate content</td>
					<td style="width: 15%" align="center">2014-10-07 18:27:39</td>
					<td class="tc3" style="width: 5%">0</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=6389">some man</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=507566#p507566">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-10-05 18:16:26</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=2781">Aoitenshi</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=2"><span class="gid1">Meredith</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=507148#p507148">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
				<tr>
					<td style="width: 25%" align="center">User has spammed</td>
					<td style="width: 15%" align="center">2014-10-03 23:51:11</td>
					<td class="tc3" style="width: 5%">1</td>
					<td class="tcr" style="width: 15%"><a href="profile.php?id=42711">sthegreat</a></td>
					<td class="tcr" style="width: 10%"><a href="profile.php?id=202"><span class="gid1">Different55</span></a></td>
					<td class="tcr" style="width: 4%">
					<p><a href="viewtopic.php?pid=506978#p506978">Post</a></p>					</td>
					<td class="tc3" style="width: 100%">  </td>
				</tr>
			</tbody>
			</table>
		</div>
	</div>
</div>
</div>

<div id="brdfooter" class="block">
	<h2><span>Board footer</span></h2>
	<div class="box">
		<div id="brdfooternav" class="inbox">
			<div class="conl">
				<form id="qjump" method="get" action="viewforum.php">
					<div><label><span>Jump to<br /></span>
					<select name="id" onchange="window.location=('viewforum.php?id='+this.options[this.selectedIndex].value)">
						<optgroup label="Announcements">
							<option value="4">Everybody Edits Announcements</option>
							<option value="11">Forum Announcements</option>
						</optgroup>
						<optgroup label="Everybody Edits">
							<option value="5">General Discussion</option>
							<option value="12">Groups</option>
							<option value="1">Rooms</option>
							<option value="7">Level Creation</option>
							<option value="25">Bots and Programming</option>
							<option value="24">Questions and Answers</option>
						</optgroup>
						<optgroup label="Feedback">
							<option value="2">Game Suggestions</option>
							<option value="16">Graphics Suggestions</option>
							<option value="10">Forum Discussion</option>
							<option value="3">Bug Reports</option>
						</optgroup>
						<optgroup label="Off-Topic">
							<option value="8">Off-Topic</option>
							<option value="22">Creative</option>
							<option value="6">Introductions</option>
							<option value="9">Forum Games</option>
							<option value="23">Topic Graveyard</option>
						</optgroup>
					</select></label>
					<input type="submit" value=" Go " accesskey="g" />
					</div>
				</form>
			</div>
			<div class="conr">

				<p id="poweredby">Powered by <a href="http://fluxbb.org/">FluxBB</a></p>
			</div>
			<div class="clearer"></div>
		</div>
		
	</div>
	
	<center>

</center>
</div>

</div>
<div class="end-box"><div><!-- Bottom corners --></div></div>
</div>

</body>
</html>
