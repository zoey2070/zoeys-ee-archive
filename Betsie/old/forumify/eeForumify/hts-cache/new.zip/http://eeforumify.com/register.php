<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="ROBOTS" content="NOINDEX, FOLLOW"/>
<title>Forum rules / Register / Everybody Edits Forums</title>
<link rel="shortcut icon" href="//favicon.ico"/>
<link rel="stylesheet" type="text/css" href="style/Novin1.css?v=2"/>
<!--[if lte IE 6]><script type="text/javascript" src="style/imports/minmax.js"></script><![endif]-->
<style type="text/css">.gid1{color:#00FF00;font-weight:bold}.gid2{color:#97FFFF;font-weight:bold}.gid10{color:#E43AFF;font-weight:bold}.gid11{color:#660099;font-weight:bold}.gid12{color:#00FFCC;font-weight:bold}.gid13{font-weight:bold}.gid14{color:#34DDDD;font-weight:bold}.gid15{color:#ff0000;font-weight:bold}.gid16{font-weight:bold}.gid17{color:#FFCC00;font-weight:bold}</style>
 
<link rel="stylesheet" media="screen" href="style/Novin1/archnavbar.css?v=14"/>
<link rel="shortcut icon" href="glasses.ico"/>
</head>
<body>
<div id="archnavbarlogo">
<img src="style/Novin1/forumheader.png" usemap="#clickable" border="none">
<map name="clickable">
<area shape="rect" coords="185, 93, 523, 17" href="index.php">
</map>
</div>
<div id="archnavbar" class="anb-forum">
<div id="archnavbarmenu">
<ul id="archnavbarlist">
<div id="archnavbaritems">
<li id="navindex"><a href="index.php">Index</a></li>
<li id="navregister" class="isactive"><a href="register.php">Register</a></li>
<li id="navlogin"><a href="login.php">Login</a></li>
<li id="navextra1"><a href="misc.php?action=rules">Rules</a></li>
<li id="navextra2"><a href="recent_warnings.php">Warnings</a></li>
</div>
</ul>
</div>
</div>
<div id="punregister" class="pun">
<div class="top-box"><div> </div>
</div>
<div class="punwrap">
<div id="brdwelcome" class="inbox">
<p class="conl">You are not logged in.</p>
<div class="clearer"></div>
</div>
</div>
<div id="announce" class="block">
<div class="hd"><h2><span>Announcement</span></h2></div>
<div class="box">
<div id="announce-block" class="inbox">
<div class="usercontent"><center><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="GW2SLCWAWZFEY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
</center></div>
</div>
</div>
</div>
<br/><br/>
<div id="brdmain">
<div id="rules" class="blockform">
<div class="hd"><h2><span>Forum rules</span></h2></div>
<div class="box">
<form method="get" action="register.php">
<div class="inform">
<fieldset>
<legend>You must agree to the following in order to register</legend>
<div class="infldset">
<div class="usercontent"><div style="text-align:center;"><div style="font-size: 2.5em;">The Supreme List of Rules</div>
Respect the forum and we will respect you.</div>
<hr><br>
<u>Be Nice</u>  <em>The Everybody Edits community is one composed of a variety of cultures, ages, languages, thoughts, and ideas. Please be respectful of your fellow players and dont forget that there is a human on the other end of the keyboard.</em><br>
<u>Dont Spam</u>  <em>No one likes to read nonsense or repeated posts, please make sure to think before you press the Submit button.</em><br>
<u>Safety/Security</u>  <em>EE hosts a wide variety of ages, from under 10 to over 50. We at EE hope to protect our members by reminding players to be aware that information posted on these forums is public, and we should never post any personal information about ourselves that could give someone an opportunity to pose a threat.</em><br>
<u>'Guardians'</u> are not allowed to post here. Any evasions will result in an IP-ban.
<br>
<br>
<center><table>
<tr>
<th>Infraction</th>
<th>Points*</th>
<th>Expires</th>
</tr>
<tr style="padding-left:100px;">
<td>Off-topic post</td>
<td>1</td>
<td>2 months</td>
</tr>
<tr>
<td>Not understandable post</td>
<td>1</td>
<td>1 week</td>
</tr>
<tr>
<td>Useless post</td>
<td>1</td>
<td>1 week</td>
</tr>
<tr>
<td>Offensive language / Evading the censors</td>
<td>1</td>
<td>1 week</td>
</tr>
<tr>
<td>Insulting other people</td>
<td>2</td>
<td>4 months</td>
</tr>
<tr>
<td>Posting explicit or offensive images</td>
<td>2</td>
<td>Never</td>
</tr>
<tr>
<td>Spamming BBCode, reports</td>
<td>1</td>
<td>1 week</td>
</tr>
<tr>
<td>Attempted ban evasion</td>
<td>1</td>
<td>1 month</td>
</tr>
<tr>
<td>Disclosing personal information of other people</td>
<td>12</td>
<td>Never</td>
</tr>
</table></center>
<br><br>
<strong>Do not...</strong><div style="padding-left:20px;">
• 2a: post useless, irrelevant, inappropriate, or incomprehensible content.<br>
• 2b: post text with unreasonable effects.<br/>
• 2c: speak in a language the opening post is not written in.<br>
• 2d: insult, annoy, or pester.<br>
• 2e: give out personal information or information of others.<br>
• 2f: use a proxy or try to evade a ban.<br>
• 2g: provide illegal tools or directions (such as a link to a pirated game).<br>
• 2h: use the report button to request stickies.<br>
• 2i: make another account without permission.<br>
• 2j: use more than four lines and/or more than 300px <strong>vertically</strong> in a signature: <a href="http://i.imgur.com/TWq1E.jpg">Example 300 max height signature</a></div><br>
<strong>Often misunderstood rules -- You may...</strong><div style="padding-left:20px;">
• 3a: post multiple times in a row if they are about different, relevant, topics.<br>
• 3b: use the report button to request a topic title change or a lock of your own topic.<br>
• 3c: use negative criticism constructively.<br>
• 3d: bump a thread if it has dropped past the first page. ("gravedig")<br>
• 3e: make an alternate account with a staff member's permission.</div><br>
<strong>Warning system</strong><br>
Refer to the chart above for point values.<br>
<div style="padding-left:20px;">
2 points = 1 hour ban<br>
4 points = 1 day ban<br>
6 points = 1 week ban<br>
8 points = 2 week ban<br>
10 points = month ban (28 days)<br>
11 points = indefinite ban
</div>
<hr>
<center>* Clause: The staff reserves the right to ban or issue warnings to any user for any reason. Or to not issue warnings/bans for any reason.</center></div>
</div>
</fieldset>
</div>
<p class="buttons"><input type="submit" name="agree" value="Agree"/> <input type="submit" name="cancel" value="Cancel"/></p>
</form>
</div>
</div>
</div>
<div id="brdfooter" class="block">
<h2><span>Board footer</span></h2>
<div class="box">
<div id="brdfooternav" class="inbox">
<div class="conl">
<form id="qjump" method="get" action="viewforum.php">
<div><label><span>Jump to<br/></span>
<select name="id" onchange="window.location=('viewforum.php?id='+this.options[this.selectedIndex].value)">
<optgroup label="Announcements">
<option value="4">Everybody Edits Announcements</option>
<option value="11">Forum Announcements</option>
</optgroup>
<optgroup label="Everybody Edits">
<option value="5">General Discussion</option>
<option value="12">Groups</option>
<option value="1">Rooms</option>
<option value="7">Level Creation</option>
<option value="25">Bots and Programming</option>
<option value="24">Questions and Answers</option>
</optgroup>
<optgroup label="Feedback">
<option value="2">Game Suggestions</option>
<option value="16">Graphics Suggestions</option>
<option value="10">Forum Discussion</option>
<option value="3">Bug Reports</option>
</optgroup>
<optgroup label="Off-Topic">
<option value="8">Off-Topic</option>
<option value="22">Creative</option>
<option value="6">Introductions</option>
<option value="9">Forum Games</option>
<option value="23">Topic Graveyard</option>
</optgroup>
</select></label>
<input type="submit" value=" Go " accesskey="g"/>
</div>
</form>
</div>
<div class="conr">
<p id="poweredby">Powered by <a href="http://fluxbb.org/">FluxBB</a></p>
</div>
<div class="clearer"></div>
</div>
</div>
<center>
</center>
</div>
</div>
<div class="end-box"><div> </div></div>
</div>
</body>
</html>
