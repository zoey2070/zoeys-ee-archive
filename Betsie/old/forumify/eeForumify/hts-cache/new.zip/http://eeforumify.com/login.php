<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="ROBOTS" content="NOINDEX, FOLLOW"/>
<title>Login / Everybody Edits Forums</title>
<link rel="shortcut icon" href="//favicon.ico"/>
<link rel="stylesheet" type="text/css" href="style/Novin1.css?v=2"/>
<script type="text/javascript">
/* <![CDATA[ */
function process_form(the_form)
{
	var required_fields = {
		"req_username": "Username",
		"req_password": "Password"
	};
	if (document.all || document.getElementById)
	{
		for (var i = 0; i < the_form.length; ++i)
		{
			var elem = the_form.elements[i];
			if(elem.type == "textarea" && elem.value.length < 8)
                {
                    alert("Your message should be at least 8 characters long!");
                    return false;
                }
                else
			if (elem.name && required_fields[elem.name] && !elem.value && elem.type && (/^(?:text(?:area)?|password|file)$/i.test(elem.type)))
			{
				alert('"' + required_fields[elem.name] + '" is a required field in this form.');
				elem.focus();
				return false;
			}
		}
	}
	return true;
}
/* ]]> */
</script>
<!--[if lte IE 6]><script type="text/javascript" src="style/imports/minmax.js"></script><![endif]-->
<style type="text/css">.gid1{color:#00FF00;font-weight:bold}.gid2{color:#97FFFF;font-weight:bold}.gid10{color:#E43AFF;font-weight:bold}.gid11{color:#660099;font-weight:bold}.gid12{color:#00FFCC;font-weight:bold}.gid13{font-weight:bold}.gid14{color:#34DDDD;font-weight:bold}.gid15{color:#ff0000;font-weight:bold}.gid16{font-weight:bold}.gid17{color:#FFCC00;font-weight:bold}</style>
 
<link rel="stylesheet" media="screen" href="style/Novin1/archnavbar.css?v=14"/>
<link rel="shortcut icon" href="glasses.ico"/>
</head>
<body onload="document.getElementById('login').elements['req_username'].focus()">
<div id="archnavbarlogo">
<img src="style/Novin1/forumheader.png" usemap="#clickable" border="none">
<map name="clickable">
<area shape="rect" coords="185, 93, 523, 17" href="index.php">
</map>
</div>
<div id="archnavbar" class="anb-forum">
<div id="archnavbarmenu">
<ul id="archnavbarlist">
<div id="archnavbaritems">
<li id="navindex"><a href="index.php">Index</a></li>
<li id="navregister"><a href="register.php">Register</a></li>
<li id="navlogin" class="isactive"><a href="login.php">Login</a></li>
<li id="navextra1"><a href="misc.php?action=rules">Rules</a></li>
<li id="navextra2"><a href="recent_warnings.php">Warnings</a></li>
</div>
</ul>
</div>
</div>
<div id="punlogin" class="pun">
<div class="top-box"><div> </div>
</div>
<div class="punwrap">
<div id="brdwelcome" class="inbox">
<p class="conl">You are not logged in.</p>
<div class="clearer"></div>
</div>
</div>
<div id="announce" class="block">
<div class="hd"><h2><span>Announcement</span></h2></div>
<div class="box">
<div id="announce-block" class="inbox">
<div class="usercontent"><center><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="GW2SLCWAWZFEY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
</center></div>
</div>
</div>
</div>
<br/><br/>
<div id="brdmain">
<div class="blockform">
<h2><span>Login</span></h2>
<div class="box">
<form id="login" method="post" action="login.php?action=in" onsubmit="return process_form(this)">
<div class="inform">
<fieldset>
<legend>Enter your username and password below</legend>
<div class="infldset">
<input type="hidden" name="form_sent" value="1"/>
<input type="hidden" name="redirect_url" value="http://eeforumify.com/index.php"/>
<label class="conl required"><strong>Username <span>(Required)</span></strong><br/><input type="text" name="req_username" size="25" maxlength="25" tabindex="1"/><br/></label>
<label class="conl required"><strong>Password <span>(Required)</span></strong><br/><input type="password" name="req_password" size="25" tabindex="2"/><br/></label>
<div class="rbox clearb">
<label><input type="checkbox" name="save_pass" value="1" tabindex="3"/>Log me in automatically each time I visit.<br/></label>
</div>
<p class="clearb">If you have not registered or have forgotten your password click on the appropriate link below.</p>
<p class="actions"><span><a href="register.php" tabindex="5">Not registered yet?</a></span> <span><a href="login.php?action=forget" tabindex="6">Forgotten your password?</a></span></p>
</div>
</fieldset>
</div>
<p class="buttons"><input type="submit" name="login" value="Login" tabindex="4"/></p>
</form>
</div>
</div>
</div>
<div id="brdfooter" class="block">
<h2><span>Board footer</span></h2>
<div class="box">
<div id="brdfooternav" class="inbox">
<div class="conl">
<form id="qjump" method="get" action="viewforum.php">
<div><label><span>Jump to<br/></span>
<select name="id" onchange="window.location=('viewforum.php?id='+this.options[this.selectedIndex].value)">
<optgroup label="Announcements">
<option value="4">Everybody Edits Announcements</option>
<option value="11">Forum Announcements</option>
</optgroup>
<optgroup label="Everybody Edits">
<option value="5">General Discussion</option>
<option value="12">Groups</option>
<option value="1">Rooms</option>
<option value="7">Level Creation</option>
<option value="25">Bots and Programming</option>
<option value="24">Questions and Answers</option>
</optgroup>
<optgroup label="Feedback">
<option value="2">Game Suggestions</option>
<option value="16">Graphics Suggestions</option>
<option value="10">Forum Discussion</option>
<option value="3">Bug Reports</option>
</optgroup>
<optgroup label="Off-Topic">
<option value="8">Off-Topic</option>
<option value="22">Creative</option>
<option value="6">Introductions</option>
<option value="9">Forum Games</option>
<option value="23">Topic Graveyard</option>
</optgroup>
</select></label>
<input type="submit" value=" Go " accesskey="g"/>
</div>
</form>
</div>
<div class="conr">
<p id="poweredby">Powered by <a href="http://fluxbb.org/">FluxBB</a></p>
</div>
<div class="clearer"></div>
</div>
</div>
<center>
</center>
</div>
</div>
<div class="end-box"><div> </div></div>
</div>
</body>
</html>
