<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Everybody Edits Forums</title>
<link rel="shortcut icon" href="//favicon.ico"/>
<link rel="stylesheet" type="text/css" href="style/Novin1.css?v=2"/>
<!--[if lte IE 6]><script type="text/javascript" src="style/imports/minmax.js"></script><![endif]-->
<style type="text/css">.gid1{color:#00FF00;font-weight:bold}.gid2{color:#97FFFF;font-weight:bold}.gid10{color:#E43AFF;font-weight:bold}.gid11{color:#660099;font-weight:bold}.gid12{color:#00FFCC;font-weight:bold}.gid13{font-weight:bold}.gid14{color:#34DDDD;font-weight:bold}.gid15{color:#ff0000;font-weight:bold}.gid16{font-weight:bold}.gid17{color:#FFCC00;font-weight:bold}</style>
 
<link rel="stylesheet" media="screen" href="style/Novin1/archnavbar.css?v=14"/>
<link rel="shortcut icon" href="glasses.ico"/>
</head>
<body>
<div id="archnavbarlogo">
<img src="style/Novin1/forumheader.png" usemap="#clickable" border="none">
<map name="clickable">
<area shape="rect" coords="185, 93, 523, 17" href="index.php">
</map>
</div>
<div id="archnavbar" class="anb-forum">
<div id="archnavbarmenu">
<ul id="archnavbarlist">
<div id="archnavbaritems">
<li id="navindex" class="isactive"><a href="index.php">Index</a></li>
<li id="navregister"><a href="register.php">Register</a></li>
<li id="navlogin"><a href="login.php">Login</a></li>
<li id="navextra1"><a href="misc.php?action=rules">Rules</a></li>
<li id="navextra2"><a href="recent_warnings.php">Warnings</a></li>
</div>
</ul>
</div>
</div>
<div id="punindex" class="pun">
<div class="top-box"><div> </div>
</div>
<div class="punwrap">
<div id="brdwelcome" class="inbox">
<p class="conl">You are not logged in.</p>
<div class="clearer"></div>
</div>
</div>
<div id="announce" class="block">
<div class="hd"><h2><span>Announcement</span></h2></div>
<div class="box">
<div id="announce-block" class="inbox">
<div class="usercontent"><center><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="GW2SLCWAWZFEY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
</center></div>
</div>
</div>
</div>
<br/><br/>
<div id="brdmain">
<div id="idx1" class="blocktable">
<h2><span>Announcements</span></h2>
<div class="box">
<div class="inbox">
<table>
<thead>
<tr>
<th class="tcl" scope="col">Forum</th>
<th class="tc2" scope="col">Topics</th>
<th class="tc3" scope="col">Posts</th>
<th class="tcr" scope="col">Last post</th>
</tr>
</thead>
<tbody>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">1</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=4">Everybody Edits Announcements</a></h3>
<div class="forumdesc">Any major news regarding Everybody Edits will be posted here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">39</td>
<td class="tc3">8,219</td>
<td class="tcr"><a href="viewtopic.php?pid=519430#p519430">Today 02:27:07</a> <span class="byuser">by <span class="gid4">Creature</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">2</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=11">Forum Announcements</a></h3>
<div class="forumdesc">Any news regarding this forum can be found in here.</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">52</td>
<td class="tc3">3,606</td>
<td class="tcr"><a href="viewtopic.php?pid=518342#p518342">2015-01-22 11:02:47</a> <span class="byuser">by <span class="gid4">AntonioS300</span></span></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div id="idx2" class="blocktable">
<h2><span>Everybody Edits</span></h2>
<div class="box">
<div class="inbox">
<table>
<thead>
<tr>
<th class="tcl" scope="col">Forum</th>
<th class="tc2" scope="col">Topics</th>
<th class="tc3" scope="col">Posts</th>
<th class="tcr" scope="col">Last post</th>
</tr>
</thead>
<tbody>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">1</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=5">General Discussion</a></h3>
<div class="forumdesc">Talk about anything related to EE here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">4,464</td>
<td class="tc3">91,128</td>
<td class="tcr"><a href="viewtopic.php?pid=519432#p519432">Today 02:50:32</a> <span class="byuser">by <span class="gid1">Different55</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">2</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=12">Groups</a></h3>
<div class="forumdesc">Are you in a group? Post your levels and group news here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">1,110</td>
<td class="tc3">38,661</td>
<td class="tcr"><a href="viewtopic.php?pid=519425#p519425">Today 02:21:44</a> <span class="byuser">by <span class="gid4">Pingohits</span></span></td>
</tr>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">3</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=1">Rooms</a></h3>
<div class="forumdesc">Share your rooms here! Tell us why we should try out your level!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">4,105</td>
<td class="tc3">40,724</td>
<td class="tcr"><a href="viewtopic.php?pid=519302#p519302">2015-02-04 22:06:25</a> <span class="byuser">by <span class="gid4">anch159</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">4</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=7">Level Creation</a></h3>
<div class="forumdesc">Making a level? Want user feedback? Need more minigame ideas? This is the place for you!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">1,719</td>
<td class="tc3">15,875</td>
<td class="tcr"><a href="viewtopic.php?pid=519304#p519304">2015-02-04 22:14:03</a> <span class="byuser">by <span class="gid4">Pingohits</span></span></td>
</tr>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">5</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=25">Bots and Programming</a></h3>
<div class="forumdesc">Have a bot that you want to share or just want to talk about programming them in general? This forum is all about bots!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">198</td>
<td class="tc3">2,912</td>
<td class="tcr"><a href="viewtopic.php?pid=519433#p519433">Today 02:58:00</a> <span class="byuser">by <span class="gid4">Security-Drone</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">6</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=24">Questions and Answers</a></h3>
<div class="forumdesc">Post any questions or guides concerning Everybody Edits here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">1,202</td>
<td class="tc3">10,755</td>
<td class="tcr"><a href="viewtopic.php?pid=519331#p519331">Yesterday 04:16:06</a> <span class="byuser">by <b style="color: #00A0ff">XxAtillaxX</b></span></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div id="idx3" class="blocktable">
<h2><span>Feedback</span></h2>
<div class="box">
<div class="inbox">
<table>
<thead>
<tr>
<th class="tcl" scope="col">Forum</th>
<th class="tc2" scope="col">Topics</th>
<th class="tc3" scope="col">Posts</th>
<th class="tcr" scope="col">Last post</th>
</tr>
</thead>
<tbody>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">1</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=2">Game Suggestions</a></h3>
<div class="forumdesc">Post your suggestions for Everybody Edits!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">2,086</td>
<td class="tc3">19,821</td>
<td class="tcr"><a href="viewtopic.php?pid=519426#p519426">Today 02:22:33</a> <span class="byuser">by <span class="gid4">Pingohits</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">2</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=16">Graphics Suggestions</a></h3>
<div class="forumdesc">Post your own graphics for Everybody Edits here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">600</td>
<td class="tc3">10,560</td>
<td class="tcr"><a href="viewtopic.php?pid=519041#p519041">2015-01-31 15:19:08</a> <span class="byuser">by <span class="gid4">Cola1</span></span></td>
</tr>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">3</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=10">Forum Discussion</a></h3>
<div class="forumdesc">Discuss anything and provide feedback related to the forum here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">1,046</td>
<td class="tc3">15,826</td>
<td class="tcr"><a href="viewtopic.php?pid=519330#p519330">Yesterday 04:10:56</a> <span class="byuser">by <b style="color: #00A0ff">XxAtillaxX</b></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">4</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=3">Bug Reports</a></h3>
<div class="forumdesc">Found an issue? Report it here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">1,884</td>
<td class="tc3">11,132</td>
<td class="tcr"><a href="viewtopic.php?pid=518908#p518908">2015-01-29 17:31:11</a> <span class="byuser">by <span class="gid4">N1KF</span></span></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div id="idx4" class="blocktable">
<h2><span>Off-Topic</span></h2>
<div class="box">
<div class="inbox">
<table>
<thead>
<tr>
<th class="tcl" scope="col">Forum</th>
<th class="tc2" scope="col">Topics</th>
<th class="tc3" scope="col">Posts</th>
<th class="tcr" scope="col">Last post</th>
</tr>
</thead>
<tbody>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">1</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=8">Off-Topic</a></h3>
<div class="forumdesc">Talk about anything here, make sure it is appropriate!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">3,725</td>
<td class="tc3">65,412</td>
<td class="tcr"><a href="viewtopic.php?pid=519429#p519429">Today 02:24:00</a> <span class="byuser">by <span class="gid4">Pingohits</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">2</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=22">Creative</a></h3>
<div class="forumdesc">Made something? Post it here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">785</td>
<td class="tc3">13,669</td>
<td class="tcr"><a href="viewtopic.php?pid=519408#p519408">Today 01:21:11</a> <span class="byuser">by <span class="gid12">BuzzerBee</span></span></td>
</tr>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">3</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=6">Introductions</a></h3>
<div class="forumdesc">Introduce yourself here.</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">768</td>
<td class="tc3">5,504</td>
<td class="tcr"><a href="viewtopic.php?pid=519394#p519394">Yesterday 23:45:17</a> <span class="byuser">by <span class="gid4">planecool</span></span></td>
</tr>
<tr class="roweven">
<td class="tcl">
<div class="icon"><div class="nosize">4</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=9">Forum Games</a></h3>
<div class="forumdesc">Play forum games here!</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">781</td>
<td class="tc3">91,313</td>
<td class="tcr"><a href="viewtopic.php?pid=519391#p519391">Yesterday 23:22:27</a> <span class="byuser">by <span class="gid4">Creature</span></span></td>
</tr>
<tr class="rowodd">
<td class="tcl">
<div class="icon"><div class="nosize">5</div></div>
<div class="tclcon">
<div>
<h3><a href="viewforum.php?id=23">Topic Graveyard</a></h3>
<div class="forumdesc">Where locked topics are laid to rest.</div>
<p class="modlist">(<em>Moderated by</em> lrussell)</p>
</div>
</div>
</td>
<td class="tc2">1,687</td>
<td class="tc3">21,000</td>
<td class="tcr"><a href="viewtopic.php?pid=510128#p510128">2014-11-01 08:01:30</a> <span class="byuser">by <b style="color: #00A0ff">XxAtillaxX</b></span></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div id="brdstats" class="block">
<h2><span>Board information</span></h2>
<div class="box">
<div class="inbox">
<dl class="conr">
<dt><strong>Board statistics</strong></dt>
<dd><span>Total number of registered users: <strong>5,696</strong></span></dd>
<dd><span>Total number of topics: <strong>26,514</strong></span></dd>
<dd><span>Total number of posts: <strong>467,897</strong></span></dd>
</dl>
<dl class="conl">
<dt><strong>User information</strong></dt>
<dd><span>Newest registered user: <span class="gid">ILoveBacon2</span></span></dd>
<dd><span>Registered users online: <strong>4</strong></span></dd>
<dd><span>Guests online: <strong>12</strong></span></dd>
</dl>
<dl id="onlinelist" class="clearb">
<dt><strong>Online: </strong></dt>
<dd>Different55,</dd>
<dd>nathskiix7811,</dd>
<dd>Security-Drone,</dd>
<dd>Slushie</dd>
</dl>
</div>
</div>
</div>
</div>
<div id="brdfooter" class="block">
<h2><span>Board footer</span></h2>
<div class="box">
<div id="brdfooternav" class="inbox">
<div class="conl">
<form id="qjump" method="get" action="viewforum.php">
<div><label><span>Jump to<br/></span>
<select name="id" onchange="window.location=('viewforum.php?id='+this.options[this.selectedIndex].value)">
<optgroup label="Announcements">
<option value="4">Everybody Edits Announcements</option>
<option value="11">Forum Announcements</option>
</optgroup>
<optgroup label="Everybody Edits">
<option value="5">General Discussion</option>
<option value="12">Groups</option>
<option value="1">Rooms</option>
<option value="7">Level Creation</option>
<option value="25">Bots and Programming</option>
<option value="24">Questions and Answers</option>
</optgroup>
<optgroup label="Feedback">
<option value="2">Game Suggestions</option>
<option value="16">Graphics Suggestions</option>
<option value="10">Forum Discussion</option>
<option value="3">Bug Reports</option>
</optgroup>
<optgroup label="Off-Topic">
<option value="8">Off-Topic</option>
<option value="22">Creative</option>
<option value="6">Introductions</option>
<option value="9">Forum Games</option>
<option value="23">Topic Graveyard</option>
</optgroup>
</select></label>
<input type="submit" value=" Go " accesskey="g"/>
</div>
</form>
</div>
<div class="conr">
<p id="poweredby">Powered by <a href="http://fluxbb.org/">FluxBB</a></p>
</div>
<div class="clearer"></div>
</div>
</div>
<center>
</center>
</div>
</div>
<div class="end-box"><div> </div></div>
</div>
</body>
</html>
