<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="ROBOTS" content="NOINDEX, FOLLOW"/>
<title>Info / Everybody Edits Forums</title>
<link rel="shortcut icon" href="//favicon.ico"/>
<link rel="stylesheet" type="text/css" href="style/Novin1.css?v=2"/>
<!--[if lte IE 6]><script type="text/javascript" src="style/imports/minmax.js"></script><![endif]-->
<style type="text/css">.gid1{color:#00FF00;font-weight:bold}.gid2{color:#97FFFF;font-weight:bold}.gid10{color:#E43AFF;font-weight:bold}.gid11{color:#660099;font-weight:bold}.gid12{color:#00FFCC;font-weight:bold}.gid13{font-weight:bold}.gid14{color:#34DDDD;font-weight:bold}.gid15{color:#ff0000;font-weight:bold}.gid16{font-weight:bold}.gid17{color:#FFCC00;font-weight:bold}</style>
 
<link rel="stylesheet" media="screen" href="style/Novin1/archnavbar.css?v=14"/>
<link rel="shortcut icon" href="glasses.ico"/>
</head>
<body>
<div id="archnavbarlogo">
<img src="style/Novin1/forumheader.png" usemap="#clickable" border="none">
<map name="clickable">
<area shape="rect" coords="185, 93, 523, 17" href="index.php">
</map>
</div>
<div id="archnavbar" class="anb-forum">
<div id="archnavbarmenu">
<ul id="archnavbarlist">
<div id="archnavbaritems">
<li id="navindex" class="isactive"><a href="index.php">Index</a></li>
<li id="navregister"><a href="register.php">Register</a></li>
<li id="navlogin"><a href="login.php">Login</a></li>
</div>
</ul>
</div>
</div>
<div id="punindex" class="pun">
<div class="top-box"><div> </div>
</div>
<div class="punwrap">
<div id="brdwelcome" class="inbox">
<p class="conl">You are not logged in.</p>
<div class="clearer"></div>
</div>
</div>
<br/><br/>
<div id="brdmain">
<div id="msg" class="block">
<h2><span>Info</span></h2>
<div class="box">
<div class="inbox">
<p>You do not have permission to view these forums.</p>
<p><a href="javascript: history.go(-1)">Go back</a></p>
</div>
</div>
</div>
</div>
<div id="brdfooter" class="block">
<h2><span>Board footer</span></h2>
<div class="box">
<div id="brdfooternav" class="inbox">
<div class="conl">
</div>
<div class="conr">
<p id="poweredby">Powered by <a href="http://fluxbb.org/">FluxBB</a></p>
</div>
<div class="clearer"></div>
</div>
</div>
<center>
</center>
</div>
</div>
<div class="end-box"><div> </div></div>
</div>
</body>
</html>
